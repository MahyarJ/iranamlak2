<form class="content check" action="login.php" method="post">

	<div class="footer-close"></div>

	<ul class="login-panel">

		<li id="username-row">

			<div class="field-label">نام کاربری:</div>

			<div><input class="textbox en" type="text" name="username"></div>

		</li>

		<li id="password-row">

			<div class="field-label">رمز عبور:</div>

			<div><input class="textbox en" type="password" name="password"></div>

		</li>

		<li id="confirm-row">

			<div class="field-label">تکرار رمز عبور:</div>

			<div><input class="textbox en" type="password" name="confirm" disabled="disabled"></div>

		</li>

		<li id="name-row">

			<div class="field-label">نام و نام خانوادگی:</div>

			<div><input class="textbox fa" type="text" name="name" disabled="disabled"></div>

		</li>

		<li id="submit-row">

			<div id="newuser" class="button">ایجاد حساب کاربری جدید</div>

			<input id="user-login-submit" class="button" type="submit" value="ورود">

		</li>

	</ul>

</form>
