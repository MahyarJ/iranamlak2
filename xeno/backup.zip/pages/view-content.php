<div class="view-content">

	<div class="view-ad-box">

		<span class="tag type">پیش فروش</span>

		<span class="tag estate">آپارتمان</span>

		<span class="tag location">تهران - لواسانات - درکه</span>

		<span class="tag date"></span>



	</div>


</div>