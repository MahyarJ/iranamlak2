<div class="window">

	<div class="bg"></div>
	<div class="window-content-box">
<!--

		<div class="ad-pane">

			<div class="ad">

				تبلیغات املـاک در اینجـا برای شمــا در نظر گرفتـــه
				شده است.تبلیغات املاک در اینجا برای شما در نظر
				گرفته شده است.

			</div>

			<div class="ad">

				تبلیغات املـاک در اینجـا برای شمــا در نظر گرفتـــه
				شده است.تبلیغات املاک در اینجا برای شما در نظر
				گرفته شده است.

			</div>

			<div class="ad">

				تبلیغات املـاک در اینجـا برای شمــا در نظر گرفتـــه
				شده است.تبلیغات املاک در اینجا برای شما در نظر
				گرفته شده است.

			</div>

			<div class="ad">

				تبلیغات املـاک در اینجـا برای شمــا در نظر گرفتـــه
				شده است.تبلیغات املاک در اینجا برای شما در نظر
				گرفته شده است.

			</div>

		</div>
 -->

		<span class="types">

			<span class="type" id="deal-type">فروش</span>

			<span class="type" id="estate-type">آپارتمان</span>

			<span class="type">|</span>

		</span>

		<span class="address-parts">

			<span class="part" id="1">تهران</span>

			<span class="part" id="2">صادقیه</span>

			<span class="part" id="3">سازمان آب</span>

			<span class="part" id="4">خیابان نهم شمالی</span>

		</span>

		<div class="estate-properties">

			<span class="window-item">

				<div class="item-title">مساحت:</div>

				<div class="item-value">125 متر</div>

			</span>


			<span class="window-item">

				<div class="item-title">قسمت واحد:</div>

				<div class="item-value">4.5 میلیون تومان</div>

			</span>


			<span class="window-item">

				<div class="item-title">قیمت کل:</div>

				<div class="item-value">562.5 میلیون تومان</div>

			</span>


			<span class="window-item">

				<div class="item-title">نعداد اتاق:</div>

				<div class="item-value">3</div>

			</span>


			<span class="window-item">

				<div class="item-title">ظبقه:</div>

				<div class="item-value">4</div>

			</span>


			<span class="window-item">

				<div class="item-title">کف پوش:</div>

				<div class="item-value">تکسرام سنگ</div>

			</span>


			<span class="window-item">

				<div class="item-title">نوع نما:</div>

				<div class="item-value">گرانیت</div>

			</span>


		</div>


		<div class="estate-options">

			<div class="window-item">

				<span class="item-title">امکانات گرمایشی / سرمایشی:</span>

				<span class="item-value">کولر   |   پکیج   |   اسپیلت</span>

			</div>

			<div class="window-item">

				<span class="item-title">فضاهای موجود ملک:</span>

				<span class="item-value">لابی   |   انباری   |   بالکن   |   پارکینگ           </span>

			</div>


		</div>

		<div class="estate-pictures">

			<div class="estate-picture"></div>

			<div class="estate-picture"></div>

			<div class="estate-picture"></div>

		</div>

		<div class="ad-box"></div>

		<div class="window-close">بازگشت »</div>

	</div>

</div>
