<?php

	include_once 'post-data.php';

	if (getValue('ad-make-submit'))
	{
		echo "
		page-title
		motion
		pictext
		text
		";

	}