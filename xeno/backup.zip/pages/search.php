<?php

	$deal = $_GET['deal'];

	$estate = $_GET['estate'];

	header("Location: ./")

?>