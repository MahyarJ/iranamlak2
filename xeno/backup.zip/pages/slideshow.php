<div class="slideshow-pg">

	<div class="slideshow-slide">

		<div class="slide-pic"></div>

		<div class="slide-text">

			<div class="main-text"></div>

			<div class="sub-text"></div>

		</div>

	</div>



</div>