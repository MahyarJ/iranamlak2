<?php

	$state = $_GET['state'];
	$city = $_GET['city'];
	$zone = $_GET['zone'];
	$address = $_GET['address'];
	$estate_type = $_GET['estate-type'];
	$deal_type = $_GET['deal-type'];

	$nama = $_GET['nama'];
	$unit_price = $_GET['unit-price'];
	$total_price = $_GET['total-price'];
	$zamin = $_GET['zamin'];
	$zirbana = $_GET['zirbana'];
	$floor = $_GET['floor'];
	$room = $_GET['room'];
	$kafpoosh = $_GET['kafpoosh'];

	$shofaj = $_GET['shofaj'];
	$pakage = $_GET['pakage'];
	$bokhari = $_GET['bokhari'];
	$kooler = $_GET['kooler'];
	$split = $_GET['split'];
	$chiler = $_GET['chiler'];
	$fankoel = $_GET['fankoel'];

	$labi = $_['labi'];
	$hayat = $_['hayat'];
	$hayatkhalvat = $_['hayatkhalvat'];
	$anbari = $_['anbari'];
	$balkon = $_['balkon'];
	$zirzamin = $_['zirzamin'];
	$parking = $_['parking'];
	$pasio = $_['pasio'];

	$open = $_GET['open'];
	$asansor = $_GET['asansor'];
	$mostakhdem = $_GET['mostakhdem'];
	$seraidar = $_GET['seraidar'];
	$pool = $_GET['pool'];
	$sona = $_GET['sona'];
	$jakoozi = $_GET['jakoozi'];




?>