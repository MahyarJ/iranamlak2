<?php

$config['dbh'] = 'localhost';
$config['dbu'] = 'root';
$config['dbp'] = '';
$config['dbn'] = 'iranamlak';
$config['auth'] = 0;

?>