<div class="news-box-content">

	<div class="news-item">

		<div class="news-thumb"></div>

		<div class="news-date">پنجشنبه 22 / 05 / 93</div>

		<div class="news-title">مجلس بازهم به وزیر پیشنهادی علوم، تحقیقات و فناوری رای اعتماد نداد</div>

		<div class="news-body">مجلس ایران صلاحیت فخرالدین احمدی دانش آشتیانی، فرد پیشنهادی برای تصدی وزارت علوم، تحقیقات و فناوری را رد کرده و باعث طرح مساله تمدید سرپرستی این وزارتخانه شده است.</div>

	</div>

	<div class="news-item">

		<div class="news-thumb"></div>

		<div class="news-date">دوشنبه 26 / 08 / 93</div>

		<div class="news-title">مذاکرات اتمی ایران؛ آغاز هفته‌ای دشوار و تعیین‌کننده</div>

		<div class="news-body">مذاکره‌کنندگان ایران و قدرت‌های جهانی به وین رفته‌اند تا در آخرین دور مذاکرات هسته‌ای، برای دست یافتن به توافقی در مورد برنامه اتمی ایران و پایان دادن به مناقشه‌ای ۱۲ ساله تلاش کنند.

			<br>مذاکره‌کنندگان ایران و قدرت‌های جهانی به وین رفته‌اند تا در آخرین دور مذاکرات هسته‌ای، برای دست یافتن به توافقی در مورد برنامه اتمی ایران و پایان دادن به مناقشه‌ای ۱۲ ساله تلاش کنند.

		</div>

	</div>

	<div class="news-item">

		<div class="news-thumb"></div>

		<div class="news-date">دوشنبه 26 / 08 / 93</div>

		<div class="news-title">مذاکرات اتمی ایران؛ آغاز هفته‌ای دشوار و تعیین‌کننده</div>

		<div class="news-body">مذاکره‌کنندگان ایران و قدرت‌های جهانی به وین رفته‌اند تا در آخرین دور مذاکرات هسته‌ای، برای دست یافتن به توافقی در مورد برنامه اتمی ایران و پایان دادن به مناقشه‌ای ۱۲ ساله تلاش کنند.

			<br>مذاکره‌کنندگان ایران و قدرت‌های جهانی به وین رفته‌اند تا در آخرین دور مذاکرات هسته‌ای، برای دست یافتن به توافقی در مورد برنامه اتمی ایران و پایان دادن به مناقشه‌ای ۱۲ ساله تلاش کنند.

		</div>

	</div>

	<?php

		// $query = "SELECT * FROM `news` ORDER BY `id` DESC";

		// $res = doquery($query);

		// while ($news = fetch($res)) {

		// 	$display_date = $news['display_date'];

		// 	$title = $news['title_fa'];

		// 	$body = $news['body_fa'];

		// 	echo "<div class=\"news-item\">" .

		// 			"<div class=\"news-date\">" . $display_date . "</div>" .

		// 			"<div class=\"news-title\">" . $title . "</div>" .

		// 			"<div class=\"news-body\">" . $body . "</div>" .

		// 		"</div>";


		// }


	?>

</div>

<script src="../scripts/js/lib/news.js"></script>